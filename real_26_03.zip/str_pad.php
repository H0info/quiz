<?php

for($i=1; $i<100; $i++)
{
	$number = sprintf('%04d',$i);
	echo $number.',';
}


?>